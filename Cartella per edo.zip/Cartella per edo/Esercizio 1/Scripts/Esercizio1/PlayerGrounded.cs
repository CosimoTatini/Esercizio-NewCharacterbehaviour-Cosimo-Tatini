using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGrounded : MonoBehaviour
{
    [SerializeField] CapsuleCollider capsuleCollider;
    [SerializeField] private float _maxDistanceGroundCheck;
    [SerializeField] private float _verticalOffsetFromStartingPoint;
   
   

    private static bool _isGrounded;
    public static bool IsGrounded => _isGrounded;

    private void Update()
    {
        Groundcheck();
    }

    private void OnDrawGizmos()
    {
        RaycastHit hit;
        Vector3 startingPoint = new Vector3(transform.position.x, transform.position.y - capsuleCollider.bounds.extents.y + _verticalOffsetFromStartingPoint, transform.position.z);

        // Esegui il Raycast con 'out hit' per ottenere informazioni sull'oggetto colpito
        bool Hitsomething = Physics.Raycast(startingPoint, Vector3.down, out hit, _maxDistanceGroundCheck);

        if (Hitsomething)
        {
            Gizmos.color = Color.green;
            // Usa 'hit.distance' per disegnare il raggio fino alla distanza dell'oggetto colpito
            Gizmos.DrawRay(startingPoint, Vector3.down * hit.distance);
        }
        else
        {
            Gizmos.color = Color.red;
            // Se non colpisce nulla, disegna il raggio fino alla distanza massima
            Gizmos.DrawRay(startingPoint, Vector3.down * _maxDistanceGroundCheck);
        }
    }

    private void Groundcheck()
    {
        Vector3 startingPoint = new Vector3(transform.position.x, transform.position.y - capsuleCollider.bounds.extents.y + _verticalOffsetFromStartingPoint, transform.position.z);
        bool hitsomething = Physics.Raycast(startingPoint,Vector3.down, out RaycastHit hitInfo,_maxDistanceGroundCheck);
        float currentYplayer = transform.position.y - capsuleCollider.bounds.extents.y;
        if(hitsomething)
        {
            _isGrounded = true;
        }
        else
        {
            _isGrounded = false;
        }
    }
}
