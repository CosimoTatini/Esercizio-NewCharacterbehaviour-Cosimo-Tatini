using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerNewShoot : MonoBehaviour
{
    [SerializeField] private Bullet _bullet;
    [SerializeField] private Transform _bulletSpawnpoint;
    [SerializeField] private int _maxBulletsCount;
    [SerializeField] private float _reloadtime;
    [SerializeField] TextMeshProUGUI _textBullets;

    [SerializeField] private float _bulletshootforce;

    private int _bulletsavailable;
    private Coroutine _reloadCouroutine;
    private readonly string _bulletbasestring = "Bullets:";
    private Camera _maincamera;

    private void Awake()
    {
        _maincamera = Camera.main;
        _bulletsavailable = _maxBulletsCount;
        UpdateBulletsString(_bulletsavailable.ToString());
    }
    private void OnEnable()
    {
        PlayerControlsManager.ShootAction += ShootAction;
    }
    private void OnDisable()
    {
        PlayerControlsManager.ShootAction += ShootAction;
    }

    private void ShootAction(InputAction.CallbackContext context)
    {
        if (context.performed) return;
        if(CanShoot())
        {
            Shoot();
        }
        else
        {
            StartReload();
        }
          
    }

    private IEnumerator Reload()
    {
        UpdateBulletsString("Reloading");
        yield return new WaitForSeconds(_reloadtime);
        _bulletsavailable = _maxBulletsCount;
        UpdateBulletsString(_bulletsavailable.ToString());
        _reloadCouroutine = null;
    }
    private void UpdateBulletsString(string v)
    {
        _textBullets.text = $"{_bulletbasestring} {v}/{_maxBulletsCount}";
    }
    private void Shoot()
    {
        _bulletsavailable--;
        UpdateBulletsString(_bulletsavailable.ToString());
        SpawnBullet();
    }

    private void SpawnBullet()
    {
        Bullet bullet = Instantiate(_bullet, _bulletSpawnpoint.position, _maincamera.transform.rotation);
        bullet.Rigidbody.AddForce(bullet.transform.forward * _bulletshootforce, ForceMode.Impulse);
    }
    private bool CanShoot()
    {
        return (_bulletsavailable > 0);
    }


    private void StartReload()
    {
        _reloadCouroutine ??= StartCoroutine(Reload());
    }

   

    
   
}
