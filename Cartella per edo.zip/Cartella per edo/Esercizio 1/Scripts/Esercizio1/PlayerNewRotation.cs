using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerNewRotation : MonoBehaviour
{
    [SerializeField] private float _horizontalSensability;
    [SerializeField] private float _verticalSensibilty;

    [SerializeField] private float _clampRange;

    [SerializeField] private Transform _cameraPoint;

    private Vector2 _rotation;
    private float _horizontalrotation;
    private float _verticalrotation;

    private Camera _maincamera;

    private void Awake()
    {
        _maincamera = Camera.main;

    }
    private void OnEnable()
    {
        PlayerControlsManager.Camerarotation += CameraRotationAction;
    }
    private void OnDisable()
    {
        PlayerControlsManager.Camerarotation += CameraRotationAction;
    }
    private void Update()
    {
        CameraFollowPlayer();
    }
    private void LateUpdate()
    {
        PlayerCameraRotation();
    }
    private void CameraRotationAction(InputAction.CallbackContext context)
    {
        _rotation = context.ReadValue<Vector2>();

        if(context.canceled)
        {
            _rotation = Vector2.zero;
        }
    }


    private void PlayerCameraRotation()
    {
        _horizontalrotation += _rotation.x * _horizontalSensability * Time.smoothDeltaTime;
        _verticalrotation += _rotation.y * _verticalSensibilty * Time.smoothDeltaTime;

        _verticalrotation = Mathf.Clamp(_verticalrotation, -_clampRange, _clampRange);

        _maincamera.transform.localRotation = Quaternion.Euler(-_verticalrotation, _horizontalrotation, 0);
        transform.rotation = Quaternion.Euler(0, _maincamera.transform.localRotation.eulerAngles.y, 0);
    }

    private void CameraFollowPlayer()
    {
        _maincamera.transform.position = _cameraPoint.position;
    }

 
}
