using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody))]
public class PlayerNewMovement : MonoBehaviour
{
   [SerializeField] private float _movementSpeed;
    private Rigidbody _rigidbody;
    private Vector2 _direction;

    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody>();
    }
    private void OnEnable()
    {
        PlayerControlsManager.Movementaction += MovementAction;
    }
    private void OnDisable()
    {
        PlayerControlsManager.Movementaction += MovementAction;
    }
    private void FixedUpdate()
    {
        MovementUpdate();
    }
    private void MovementAction(InputAction.CallbackContext context)
    {
        if (!(context.performed || context.canceled)) return;

        _direction = context.ReadValue<Vector2>();
        Debug.Log(_direction);

        if(_direction== Vector2.zero)
        {
            _rigidbody.velocity = new Vector3(0, _rigidbody.velocity.y, 0);
        }
    }
    private void MovementUpdate()
    {
        Vector3 _movedirection = math.normalizesafe(transform.forward) * _direction.y + 
        math.normalizesafe(transform.right) * _direction.x;

        _rigidbody.velocity = new Vector3(math.normalizesafe(_movedirection).x * _movementSpeed * Time.fixedDeltaTime, _rigidbody.velocity.y, math.normalizesafe(_movedirection).z * _movementSpeed * Time.fixedDeltaTime);
    }

    
}
