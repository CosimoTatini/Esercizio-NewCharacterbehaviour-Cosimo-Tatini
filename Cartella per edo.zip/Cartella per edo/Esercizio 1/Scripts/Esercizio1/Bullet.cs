using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] private float _destroyTime;
    private Rigidbody _rigidbody;

    public Rigidbody Rigidbody => _rigidbody;
    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody>();
        Destroy(gameObject, _destroyTime);
    }
}
