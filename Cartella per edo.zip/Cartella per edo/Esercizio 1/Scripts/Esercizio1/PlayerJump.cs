using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody), typeof(PlayerGrounded))]
public class PlayerJump : MonoBehaviour
{
    [SerializeField] private float _jumpforce;
    [SerializeField] private float _jumpBufferedtime;
    private float _jumpbufferedcounter;

    private bool _isGrounded;
   private bool _startedJumping;
    private bool _isJumping;

   private Rigidbody _rigidbody;

    private void Awake()
    {
       _rigidbody = GetComponent<Rigidbody>();
    }
    private void OnEnable()
    {
        PlayerControlsManager.JumpAction += JumpAction;
    }

    private void OnDisable()
    {
        PlayerControlsManager.JumpAction += JumpAction;
    }

    private void Update()
    {
        UpdateGroundedState();
        BufferedJumpHandler();
    }
    private void JumpAction(InputAction.CallbackContext context)
    {
        if (!context.performed) return;
        if (CanJump()) Jump();
    }

   
    private bool CanJump()
    {
       if (!_isGrounded)
       {
            _jumpbufferedcounter = _jumpBufferedtime;
            UnityEngine.Debug.Log(" Preparing buffered jump");
            return false;
       }
        return true;
    }
    private void Jump()
    {
        _startedJumping = true;

        _rigidbody.velocity = new Vector3(_rigidbody.velocity.x, 0, _rigidbody.velocity.z);
        _rigidbody.AddForce(Vector3.up * _jumpforce, ForceMode.Impulse);
    }
    private void UpdateGroundedState()
    {
        _isGrounded = PlayerGrounded.IsGrounded;
    }

    private void BufferedJumpHandler()
    {
       if(_isGrounded)
       {
         if (_startedJumping && _isJumping)
         {
           _startedJumping = false;
           _isJumping = false;
         }
         if ( _jumpbufferedcounter > 0f)
         {
           _jumpbufferedcounter = 0f;
           UnityEngine.Debug.Log("Buffered jump");
            Jump();

         }

       }
       else
       {
         if(_startedJumping)
         {
          _isJumping = true;
           
         }
            _jumpbufferedcounter = (_jumpbufferedcounter > 0f) ? _jumpbufferedcounter - Time.deltaTime : 0f;
       }

    }

    
   



}
